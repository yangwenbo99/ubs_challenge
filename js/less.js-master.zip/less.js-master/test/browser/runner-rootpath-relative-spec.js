describe('less.js browser test - rootpath and relative urls', function() {
    testLessEqualsInDocument();
});
